#include<stdio.h>
#include<stdlib.h>
#include"boolean.h"
#include"listrek.h"
#include"bintree.h"

int main(){
    
}